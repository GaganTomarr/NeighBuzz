package com.infy.lcp.entity;

public enum ContactType {
	EMAIL,SMS,MOBILENO,NONE
}
