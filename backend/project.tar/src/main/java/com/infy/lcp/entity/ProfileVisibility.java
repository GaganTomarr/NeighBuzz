package com.infy.lcp.entity;

public enum ProfileVisibility {
	PUBLIC,PRIVATE
}
