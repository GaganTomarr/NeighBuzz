package com.infy.lcp.entity;

public enum AccountStatus {
	ACTIVE,SUSPENDED,INACTIVE, DELETED
}
