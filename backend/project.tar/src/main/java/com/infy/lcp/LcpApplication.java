package com.infy.lcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LcpApplication {

	public static void main(String[] args) {
		SpringApplication.run(LcpApplication.class, args);
	}

}
