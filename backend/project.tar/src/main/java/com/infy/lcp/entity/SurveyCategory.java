package com.infy.lcp.entity;

public enum SurveyCategory {
NEWS, DISCUSSION, FEEDBACK, EVENTS, CONTENT
}
