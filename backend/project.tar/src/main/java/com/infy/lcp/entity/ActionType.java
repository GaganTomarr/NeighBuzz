package com.infy.lcp.entity;

public enum ActionType {

	APPROVE, REJECT, DELETE, SUSPEND, RESTORE
}
