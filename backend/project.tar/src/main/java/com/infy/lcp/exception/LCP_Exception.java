package com.infy.lcp.exception;

public class LCP_Exception extends Exception {

	private static final long serialVersionUID = 1L;

	public LCP_Exception(String message) {
		super(message);	
	}
}
