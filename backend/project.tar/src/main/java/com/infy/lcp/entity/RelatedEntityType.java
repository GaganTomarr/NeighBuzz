package com.infy.lcp.entity;

public enum RelatedEntityType {
	EVENT, FORUM_THREAD_DISCUSSION, SYSTEM, NEWS_POST_COMMENT_REPLY
}
