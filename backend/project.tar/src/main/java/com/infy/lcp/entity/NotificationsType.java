package com.infy.lcp.entity;

public enum NotificationsType {
	EVENT_UPDATE, SYSTEM, EVENTS_ADDED, COMMENT_REPLY, FORUM_THREAD_DISCUSSION
}