package com.infy.lcp.entity;

public enum ActivityType {
	LOGIN, POST_CREATED, COMMENT, RSVP, FORUM_POST, SURVEY_SUBMIT, EVENT_CREATED
}
