package com.infy.lcp.entity;

public enum EntityType {

	POST, EVENT, THREAD, SURVEY, COMMENT, SYSTEM
}
