package com.infy.lcp.entity;

public enum ContentType {
	POST, COMMENT, THREAD, EVENT, SURVEY, USER
//	NEWS, PAGES, SOCIAL_MEDIA,EVENT,FORUM_POST
}
