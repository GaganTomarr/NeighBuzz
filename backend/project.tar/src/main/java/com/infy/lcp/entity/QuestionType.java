package com.infy.lcp.entity;

public enum QuestionType {
	MULTIPLE_CHOICE,
    DROPDOWN
}
