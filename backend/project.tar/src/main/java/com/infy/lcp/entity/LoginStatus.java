package com.infy.lcp.entity;

public enum LoginStatus {
	SUCCESS,FAILED,LOCKOUT
}
