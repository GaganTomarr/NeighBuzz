package com.infy.lcp.entity;

public enum RegistrationStatus {
REGISTERED,WAITLISTED,CANCELLED
}
