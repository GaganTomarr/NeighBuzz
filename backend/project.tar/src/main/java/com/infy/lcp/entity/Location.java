package com.infy.lcp.entity;

public enum Location {
	GENERAL, MUMBAI, DELHI, BENGALURU, HYDERABAD, AHMEDABAD, CHENNAI, KOLKATA, SURAT, PUNE, JAIPUR
}